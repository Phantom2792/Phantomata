# Phantomata
A Python Library to formulate Turing Machines and other models based on automata theory
